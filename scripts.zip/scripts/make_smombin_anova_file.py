"""Convert the raw zone-of-inhibition sheet into the long-format ANOVA file for the S. mombin extract.

Input : data/raw/Raw_Inhibition_Zone_Diameter_Readings.csv  (three readings per isolate; extract and levofloxacin columns)
Output: data/processed/Smombin_zones_anova_file.csv          (sample_id, organism, gram_status, phenotype,
                                                              concentration_mg_ml, replicate, zone_mm)

Only the S. mombin columns (400, 200 and 100 mg/mL) are exported. The solvent-system column is omitted because every
reading is 0 mm. Levofloxacin results for the same isolates are published separately (Abdullahi et al., 2026,
Bull Natl Res Cent 50:66; doi:10.1186/s42269-026-01459-y).
Run from the repository root:  python scripts/make_smombin_anova_file.py
"""
import csv
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RAW = ROOT / "data" / "raw" / "Raw_Inhibition_Zone_Diameter_Readings.csv"
OUT = ROOT / "data" / "processed" / "Smombin_zones_anova_file.csv"

# sample_id, organism code, Gram status, resistance phenotype (as in Table 1 of the article)
META = [
    (1, 'N 19', 'Gram Negative', 'ESBL producer'),
    (2, 'N 24', 'Gram Negative', 'ESBL producer'),
    (3, 'Med 1(2)', 'Gram Negative', 'EPA; ESBL producer'),
    (4, 'OG 1(3)', 'Gram Negative', 'EPA'),
    (5, 'OG 1(4)', 'Gram Negative', 'EPA; ESBL producer'),
    (6, 'Oga', 'Gram Negative', 'ESBL producer'),
    (7, 'Med 5(1)', 'Gram Negative', 'AmpC β-lactamase producer'),
    (8, 'N 14', 'Gram Negative', 'ESBL producer'),
    (9, 'N 3', 'Gram Negative', 'ESBL producer'),
    (10, 'PA 24', 'Gram Negative', 'None'),
    (11, 'Es 44', 'Gram Positive', 'EPA; ORSA; Carbapenemase'),
    (12, 'Med 4 (2)', 'Gram Positive', 'EPA; ORSA; Carbapenemase'),
    (13, 'Es 14', 'Gram Positive', 'ORSA'),
    (14, 'Es 16', 'Gram Positive', 'ORSA'),
    (15, 'Es 21', 'Gram Positive', 'ORSA; Carbapenemase'),
    (16, 'ML 10', 'Gram Positive', 'Carbapenemase'),
    (17, 'Es 7', 'Gram Positive', 'EPA; ORSA; Carbapenemase'),
    (18, 'EF 24', 'Gram Positive', 'None'),
    (19, 'ATCC 25922', 'Gram Negative', 'ATCC 25922'),
    (20, 'ATCC 25923', 'Gram Positive', 'ATCC 25923'),
]
COLUMNS = {400: 0, 200: 2, 100: 4}   # positions of the S. mombin columns among the eight reading columns


def norm(code):
    return re.sub(r"\s+", "", code).lower()


def main():
    with open(RAW, encoding="utf-8", newline="") as f:
        rows = list(csv.reader(f))
    readings, current = {}, None
    for r in rows:
        if len(r) > 2 and r[0].strip().isdigit() and "Reading" in r[2]:
            current = norm(r[1].split("\n")[0].strip())
            readings[current] = []
        if current and len(r) > 10 and "Reading" in r[2]:
            readings[current].append([int(x) for x in r[3:11]])
    out = []
    for sid, code, gram, phen in META:
        reps = readings[norm(code)]
        assert len(reps) == 3, code
        for conc, col in COLUMNS.items():
            for i, rd in enumerate(reps, 1):
                out.append([sid, code, gram, phen, conc, i, rd[col]])
    OUT.parent.mkdir(parents=True, exist_ok=True)
    with open(OUT, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["sample_id", "organism", "gram_status", "phenotype", "concentration_mg_ml", "replicate", "zone_mm"])
        w.writerows(out)
    print(f"{len(out)} rows written to {OUT}")


if __name__ == "__main__":
    main()
