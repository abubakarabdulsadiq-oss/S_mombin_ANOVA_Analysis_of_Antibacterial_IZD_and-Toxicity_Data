"""Fig. 2 of the article: concentration-response of S. mombin extract in the agar well diffusion assay.

Run from the repository root:  python scripts/make_figure2.py   ->  results/Fig2_concentration_response.png
"""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
d = pd.read_csv(ROOT / "data" / "processed" / "Smombin_zones_anova_file.csv")
(ROOT / "results").mkdir(exist_ok=True)

plt.rcParams.update({"font.family": "DejaVu Serif", "font.size": 9})
fig, ax = plt.subplots(1, 2, figsize=(6.5, 2.8), sharey=True)

s = d.groupby("concentration_mg_ml").zone_mm.agg(["mean", "sem"])
ax[0].errorbar(s.index, s["mean"], yerr=s["sem"], marker="o", color="#1f4e79", capsize=3, lw=1.4)
for x, (m, e), lab in zip(s.index, s.values, ["c", "b", "a"]):   # Tukey HSD letters (all pairs p < 0.001)
    ax[0].text(x, m + e + 0.8, lab, ha="center", fontsize=9)
ax[0].set_title("(A) All isolates (n = 20)", fontsize=9, loc="left")

styles = {"Gram Negative": ("Gram-negative (n = 11)", "#1f4e79", "o"),
          "Gram Positive": ("Gram-positive (n = 9)", "#c55a11", "s")}
for g, (lab, c, mk) in styles.items():
    s = d[d.gram_status == g].groupby("concentration_mg_ml").zone_mm.agg(["mean", "sem"])
    ax[1].errorbar(s.index, s["mean"], yerr=s["sem"], marker=mk, color=c, capsize=3, lw=1.4, label=lab)
ax[1].legend(frameon=False, fontsize=8, loc="upper left")
ax[1].set_title("(B) By Gram reaction", fontsize=9, loc="left")

for a in ax:
    a.set_xticks([100, 200, 400])
    a.set_xlabel("Extract concentration (mg/mL)")
    a.spines[["top", "right"]].set_visible(False)
    a.set_ylim(0, 27)
ax[0].set_ylabel("Zone of inhibition (mm)")
fig.tight_layout()
fig.savefig(ROOT / "results" / "Fig2_concentration_response.png", dpi=300)
print("Saved results/Fig2_concentration_response.png")
